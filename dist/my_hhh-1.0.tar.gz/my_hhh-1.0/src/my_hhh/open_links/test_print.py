def test_print1():
    print("test print")
#.def